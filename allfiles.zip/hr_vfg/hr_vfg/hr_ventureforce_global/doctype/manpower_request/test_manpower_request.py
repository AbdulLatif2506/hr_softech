# Copyright (c) 2023, VFG and Contributors
# See license.txt

# import frappe
import unittest

class TestManpowerRequest(unittest.TestCase):
	pass
