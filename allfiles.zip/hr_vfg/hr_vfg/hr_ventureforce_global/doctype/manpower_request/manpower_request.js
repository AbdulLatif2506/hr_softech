// Copyright (c) 2023, VFG and contributors
// For license information, please see license.txt

frappe.ui.form.on('Manpower Request', {
	// refresh: function(frm) {

	// }
});
