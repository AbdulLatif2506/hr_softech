# Copyright (c) 2024, VFG and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestOvertimeForm(FrappeTestCase):
	pass
