# Copyright (c) 2023, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
import unittest

class TestTransfer(unittest.TestCase):
	pass
