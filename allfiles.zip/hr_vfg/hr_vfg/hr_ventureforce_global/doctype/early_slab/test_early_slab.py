# Copyright (c) 2023, VFG and Contributors
# See license.txt

# import frappe
import unittest

class TestEarlySlab(unittest.TestCase):
	pass
