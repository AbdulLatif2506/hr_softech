// Copyright (c) 2024, VFG and contributors
// For license information, please see license.txt

frappe.ui.form.on('Year', {
	// refresh: function(frm) {

	// }
});
